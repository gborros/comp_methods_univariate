
########### FIRST UPLOAD YOUR DATA INTO R ######################

######### In order to run P2 GA do either of the above: ########

### RUN THESE: ###

getwd()
setwd("C:\\Users\\TIMUR\\Desktop\\My Dropbox\\My Dropbox\\GA4STRATA")
setwd("C:\\Documents and Settings\\SamsungXP\\Belgelerim\\My Dropbox\\GA4STRATA")

data=read.table("iso487.txt")

##### FOR P1, P2, P3 and P4 #########

source("GA4Stratification.R")
source("sebnemGeneticP2.R")
source("randomnumGenerator.R")
source("sebnemGeneticP2fit.R")
source("sebnemGeneticP2m.R")
source("sebnemGeneticP2fitt.R")
source("sebnemGeneticP2.R")
source("sebnemGeneticSelection.R")
source("sebnemGeneticP2x.R")

GA4Stratification(data)
### OR INDIVIDUALLY YOU CAN RUN sebnemGeneticP2  LIKE THIS###

sebnemGeneticP2(data,3,81,15,55,0.1)

library(debug)
mtrace(sebnemGeneticP4fit)

package.skeleton(name="geneticStrat")

data=read.table("F:/iso487.txt")