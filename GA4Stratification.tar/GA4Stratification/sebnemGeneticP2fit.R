 sebnemGeneticP2fit=function(randpop,data,nofstrata,ssize)
{
   nocrom=nrow(randpop)
   c=nrow(data)
   fitp1=array(0,dim=c(1,nocrom))
   fit=array(0,dim=c(nocrom,1))
   N=array(0,dim=c(nocrom,nofstrata))
   means=array(0,dim=c(nocrom,nofstrata))
   s=array(0,dim=c(nocrom,nofstrata))
   n=array(0,dim=c(nocrom,nofstrata))
   vars=array(0,dim=c(nocrom,nofstrata))
   mas=array(0,dim=c(nocrom,nofstrata))
   NN=array(0,dim=c(nocrom,nofstrata))
   k=array(0,dim=c(nocrom,nofstrata))
   p=array(0,dim=c(nocrom,nofstrata))
   t=array(0,dim=c(nocrom,nofstrata))
   dd=array(0,dim=c(nocrom,1))
   toplam=cumsum(data)
   sumSquares=cumsum(data^2)

   for ( i in 1:nocrom )
   {
   	mas[i,]=which(randpop[i,]==1,arr.ind=T)
    	N[i,1]=min(mas[i,])
    	means[i,1]=toplam[mas[i,1],]/N[i,1]
    	s[i,1]=((N[i,1]/(N[i,1]-1))*(sumSquares[N[i,1],1]/N[i,1]-means[i,1]^2))^.5

    	for ( j in 2:nofstrata )
		{    
    		N[i,j]=mas[i,j]-mas[i,(j-1)]
			N
	      	means[i,j]=(toplam[mas[i,j],]-toplam[mas[i,j-1],])/N[i,j]
			means
      		s[i,j]=((N[i,j]/(N[i,j]-1))*((sumSquares[mas[i,j],1]-sumSquares[mas[i,j-1],1])/N[i,j]-means[i,j]^2))^.5
			s
		}   

    	for ( j in 1:nofstrata )
		{
      		n[i,j]=max(1,floor(ssize*N[i,j]/sum(N[i,])))
        	n[i,j]=min(n[i,j],N[i,j])
		}
		if ( ssize-sum(n[i,])>0 )
		{
      	k[i,]=N[i,]-n[i,]
        	t[i,]=max(k[i,])
        	p[i,]=which(k[i,]==t[i,],arr.ind=T)[1]
        	n[i,p[i,1]]=min(n[i,p[i,1]]+ssize-sum(n[i,]),N[i,p[i,1]])
		}

		for ( j in 1:nofstrata )
		{
        	vars[i,j]=((N[i,j]-n[i,j])*s[i,j]^2*N[i,j]^2)/(c^2*n[i,j]*N[i,j])
		}

    	dd[i,]=min((N[i,]-n[i,]))
    	NN[i,]=cumsum(N[i,])
    	kl=0

   		fit[i,]=sum(vars[i,])

    	if ( dd[i]<0 ) 
		{
			fit[i]= 9999999999999999
    	} else if (!all(N[i,]!=1)) 
		{
			fit[i]= 999999999999999999
    	} else if (!all(N[i,]!=0)) 
		{
			fit[i]= 999999999999999999
		} else
		{
			fit[i]=fit[i]
		}
   
    	for ( j in 1:(nofstrata-1) )
		{
        	kl=kl+data[(NN[i,j]+1),]-data[NN[i,j],]
		}

    	p2fit=array(-fit,dim=c(nocrom,1))

		#sebnemGeneticP2fit=p2fit    
   }
   return(p2fit)
}
