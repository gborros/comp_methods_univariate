sebnemGeneticP4=function(data,nofstrata,ssize,iteration,popsize,mutrate)
{
   sutun=nrow(data)
   randpop=array(0,dim=c(popsize,sutun+nofstrata))
   randomNumbers=array(0,dim=c(popsize,nofstrata-1))
   samples=array(0,dim=c(popsize,nofstrata))
   sumSamples=array(0,dim=c(popsize,nofstrata))

   for (i in 1:popsize)
   {
	randomNumbers[i,]=randomnumGenerator(sutun,nofstrata)
	samples[i,]=floor(runif(3,1,10))
	sumSamples[i,]=sum(samples[i,])
   }
   samples=floor(samples/sumSamples*ssize)
   son=array(sutun,dim=c(popsize,1))
   indis=array(c(1:popsize,randomNumbers,son),dim=c(popsize,(nofstrata+1)))

   for(i in 2:(nofstrata+1))
   {
   	randpop[indis[,c(1,i)]]=1
   }

   for ( i in 1:popsize )
   {
	samples[i,nofstrata]=samples[i,nofstrata]+ssize-sum(samples[i,])
   }

   randpop[,(sutun+1):(sutun+nofstrata)]=samples
	#---------------------------------------------
	# Baslangic populasyonunun belirlenmesi
	#---------------------------------------------

   bestval=-99999999999999999999999999999999999999999999999999999999999999
   for ( i in 1:iteration )
   {

	fitnesspop=sebnemGeneticP4fit(randpop,data,nofstrata,ssize)
	if ( max(fitnesspop)>bestval )
	{
	    bestval=max(fitnesspop)
	    bestloc=randpop[max(which(fitnesspop==bestval)),]
	    #iter_fitness=[i,-bestval]
	}
	#-------------------------------------------
	#Se�im operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticSelection(randpop,fitnesspop)


	#-------------------------------------------
	#�aprazlama operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticP4x(randpop,bestloc,data,nofstrata,ssize,fitnesspop)


	#-------------------------------------------
	# Mutasyon operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticP4m(randpop,nofstrata,mutrate,i)

	randpop[floor(runif(1, 1,popsize)),]=bestloc

      randpop
	cat(i, " ",-bestval,'\n')
	#print(paste("For iteration ",i," the fitness is ",-bestval))
	#message(paste("Iteration ",i," ",-bestval,sep=""))
	#print(sprintf("Iteration: %f",-bestval))
	flush.console()
	Sys.sleep(1)
   }
   sebnemGeneticP4fitt(bestloc,data,nofstrata,ssize,-bestval)
}