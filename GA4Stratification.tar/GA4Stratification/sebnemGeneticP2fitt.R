sebnemGeneticP2fitt=function(bestloc,data,nofstrata,ssize,bestval)
{
   c=nrow(data)
   nocrom=length(bestloc)/c
   bestloc=array(bestloc,dim=c(length(bestloc)/c,c))
   fitp1=array(0,dim=c(1,nocrom))
   fit=array(0,dim=c(nocrom,1))
   N=array(0,dim=c(nocrom,nofstrata))
   means=array(0,dim=c(nocrom,nofstrata))
   s=array(0,dim=c(nocrom,nofstrata))
   n=array(0,dim=c(nocrom,nofstrata))
   vars=array(0,dim=c(nocrom,nofstrata))
   mas=array(0,dim=c(nocrom,nofstrata))
   NN=array(0,dim=c(nocrom,nofstrata))
   k=array(0,dim=c(nocrom,nofstrata))
   p=array(0,dim=c(nocrom,nofstrata))
   t=array(0,dim=c(nocrom,nofstrata))
   dd=array(0,dim=c(nocrom,1))
   toplam=cumsum(data)
   sumSquares=cumsum(data^2)

   for ( i in 1:nocrom )
   {

   	mas[i,]=which(bestloc[i,]==1,arr.ind=T)
    	N[i,1]=min(mas[i,])
    	means[i,1]=toplam[mas[i,1],]/N[i,1]
    	s[i,1]=((N[i,1]/(N[i,1]-1))*(sumSquares[N[i,1],1]/N[i,1]-means[i,1]^2))^.5

    	for ( j in 2:nofstrata )
		{    
    		N[i,j]=mas[i,j]-mas[i,(j-1)]
			N
	      	means[i,j]=(toplam[mas[i,j],]-toplam[mas[i,j-1],])/N[i,j]
			means
      		s[i,j]=((N[i,j]/(N[i,j]-1))*((sumSquares[mas[i,j],1]-sumSquares[mas[i,j-1],1])/N[i,j]-means[i,j]^2))^.5
			s
		}   

    	for ( j in 1:nofstrata )
		{
      		n[i,j]=max(1,floor(ssize*N[i,j]/sum(N[i,])))
        	n[i,j]=min(n[i,j],N[i,j])
		}
		if ( ssize-sum(n[i,])>0 )
		{
      		k[i,]=N[i,]-n[i,]
        	t[i,]=max(k[i,])
        	p[i,]=which(k[i,]==t[i,],arr.ind=T)
        	n[i,p[i,1]]=min(n[i,p[i,1]]+ssize-sum(n[i,]),N[i,p[i,1]])
		}
   }

   return(array(c(N,n,bestval),dim=c(nofstrata,3)))
}
