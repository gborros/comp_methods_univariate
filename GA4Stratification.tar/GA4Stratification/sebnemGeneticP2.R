sebnemGeneticP2=function(data,nofstrata,ssize,iteration,popsize,mutrate)
{
   #data=read.table("C:\\data.txt")
   sutun=nrow(data)
   randpop=array(0,dim=c(popsize,sutun))
   randomNumbers=array(0,dim=c(popsize,nofstrata-1))

   for (i in 1:popsize)
   {
	randomNumbers[i,]=randomnumGenerator(sutun,nofstrata)
   }
   

   son=array(sutun,dim=c(popsize,1))
   indis=array(c(1:popsize,randomNumbers,son),dim=c(popsize,(nofstrata+1)))

   for(i in 2:(nofstrata+1))
   {
   	randpop[indis[,c(1,i)]]=1
   }

	#---------------------------------------------
	# Baslangic populasyonunun belirlenmesi
	#---------------------------------------------

   bestval=-99999999999999999999999999999999999999999999999999999999999999
   for ( i in 1:iteration )
   {

	fitnesspop=sebnemGeneticP2fit(randpop,data,nofstrata,ssize)
	if ( max(fitnesspop)>bestval )
	{
	    bestval=max(fitnesspop)
	    bestloc=randpop[max(which(fitnesspop==bestval)),]
	    #iter_fitness=[i,-bestval]
	}
	#-------------------------------------------
	#Se�im operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticSelection(randpop,fitnesspop)


	#-------------------------------------------
	#�aprazlama operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticP2x(randpop,bestloc,data,nofstrata,ssize,fitnesspop)


	#-------------------------------------------
	# Mutasyon operat�r�n�n uygulanmasi.
	#-------------------------------------------

	randpop=sebnemGeneticP2m(randpop,nofstrata,mutrate,i)

	randpop[floor(runif(1, 1,popsize)),]=bestloc
      randpop
	cat(i, " ",-bestval,'\n')
	#print(paste("For iteration ",i," the fitness is ",-bestval))
	#message(paste("Iteration ",i," ",-bestval,sep=""))
	#print(sprintf("Iteration: %f",-bestval))
	flush.console()
	Sys.sleep(1)
   }
   sebnemGeneticP2fitt(bestloc,data,nofstrata,ssize,-bestval)
}