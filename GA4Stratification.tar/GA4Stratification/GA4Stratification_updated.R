GA4Stratification=function(data, nofstrata, ssize, popsize, iteration, mutrate, sampleAllocation)
{
  source("randomnumGenerator.R")
  source("GA4StratificationSelection.R")
  # nofstrata = readline("What is the number of strata?")
  # ssize = readline("What is the total sample size?")
  # popsize = readline("What is the size of the GA Population? Please write an integer between 30-60.")
  # iteration = readline("How many iterations do you want?")
  # mutrate = readline("What is the mutation rate?")
  # 
  nofstrata = as.numeric(nofstrata)
  ssize = as.numeric(ssize)
  popsize  = as.numeric(popsize)
  iteration  = as.numeric(iteration)
  mutrate  = as.numeric(mutrate)
  
  # sampleAllocation = menu(c("Equal","Proportional","Neyman", "GA"), graphics = TRUE, title = "What is the sample allocation method?") #stores in dist
  
  if(sampleAllocation == 1)
  {
    source("GA4StratificationP1.R")
    source("GA4StratificationP1fit.R")
    source("GA4StratificationP1fitt.R")
    source("GA4StratificationP1x.R")
    source("GA4StratificationP1m.R")
    GA4StratificationP1(data,nofstrata,ssize,iteration,popsize,mutrate)
    
  } else if(sampleAllocation==2) {
    
    source("GA4StratificationP2.R")
    source("GA4StratificationP2fit.R")
    source("GA4StratificationP2fitt.R")
    source("GA4StratificationP2x.R")
    source("GA4StratificationP2m.R")
    GA4StratificationP2(data,nofstrata,ssize,iteration,popsize,mutrate)
    
  } else if(sampleAllocation == 3) {
    
    source("GA4StratificationP3.R")
    source("GA4StratificationP3fit.R")
    source("GA4StratificationP3fitt.R")
    source("GA4StratificationP3x.R")
    source("GA4StratificationP3m.R")
    GA4StratificationP3(data,nofstrata,ssize,iteration,popsize,mutrate)
    
  } else {
    
    source("GA4StratificationP4.R")
    source("GA4StratificationP4fit.R")
    source("GA4StratificationP4fitt.R")
    source("GA4StratificationP4x.R")
    source("GA4StratificationP4m.R")
    GA4StratificationP4(data,nofstrata,ssize,iteration,popsize,mutrate)
    
  }
  
}
