GA4Stratification=function(data)
{
   source("randomnumGenerator.R")
   source("sebnemGeneticSelection.R")
   nofstrata = winDialogString("What is the number of strata?", "")
   ssize = winDialogString("What is the total sample size?", "")
   popsize = winDialogString("What is the size of the GA Population? Please write an integer between 30-60.", "")
   iteration = winDialogString("How many iterations do you want?", "")
   mutrate = winDialogString("What is the mutation rate?", "")

   nofstrata = as.numeric(nofstrata)
   ssize = as.numeric(ssize)
   popsize  = as.numeric(popsize)
   iteration  = as.numeric(iteration)
   mutrate  = as.numeric(mutrate)

   sampleAllocation = menu(c("Equal","Proportional","Neyman", "GA"), graphics = TRUE, title = "What is the sample allocation method?") #stores in dist

   if(sampleAllocation == 1)
   {
	source("sebnemGeneticP1.R")
	source("sebnemGeneticP1fit.R")
	source("sebnemGeneticP1fitt.R")
	source("sebnemGeneticP1x.R")
	source("sebnemGeneticP1m.R")
	sebnemGeneticP1(data,nofstrata,ssize,iteration,popsize,mutrate)
	
   } else if(sampleAllocation==2) {
	
	source("sebnemGeneticP2.R")
	source("sebnemGeneticP2fit.R")
	source("sebnemGeneticP2fitt.R")
	source("sebnemGeneticP2x.R")
	source("sebnemGeneticP2m.R")
	sebnemGeneticP2(data,nofstrata,ssize,iteration,popsize,mutrate)

   } else if(sampleAllocation == 3) {
	
	source("sebnemGeneticP3.R")
	source("sebnemGeneticP3fit.R")
	source("sebnemGeneticP3fitt.R")
	source("sebnemGeneticP3x.R")
	source("sebnemGeneticP3m.R")
	sebnemGeneticP3(data,nofstrata,ssize,iteration,popsize,mutrate)
   
   } else {

	source("sebnemGeneticP4.R")
	source("sebnemGeneticP4fit.R")
	source("sebnemGeneticP4fitt.R")
	source("sebnemGeneticP4x.R")
	source("sebnemGeneticP4m.R")
	sebnemGeneticP4(data,nofstrata,ssize,iteration,popsize,mutrate)

   }

}
