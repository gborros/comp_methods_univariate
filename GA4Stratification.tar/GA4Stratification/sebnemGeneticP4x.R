 sebnemGeneticP4x=function(dizi,bestloc,data,nofstrata,ssize,fitnesspop)
 {
   #parentsuygunluk=sebnemGeneticP4fit(dizi,data,nofstrata,ssize)
   parentsuygunluk=fitnesspop
   parents=cbind(dizi,parentsuygunluk)
   dizip=dizi
   satir=nrow(dizi)
   sutun=ncol(dizi)

   randomNumbers=array(0,dim=c(satir,2))
   
   for (i in 1:satir)
   {
	randomNumbers[i,]=randomnumGenerator(satir,nofstrata)
   }
   anne=baba=NULL
   for (i in 1:satir)
   {
	  anne=randomNumbers[i,1]
	  baba=randomNumbers[i,2]
   
    	  crosspoint=floor(runif(1, 1,(sutun-1)))
        while ( sum(dizip[anne,c(1:crosspoint)])!=sum(dizip[baba,c(1:crosspoint)]) )
        {
		crosspoint=floor(runif(1, 1,(sutun-1)))
	  }
    	  dizi[i,c(1:crosspoint)]=dizip[anne,c(1:crosspoint)]
        dizi[i,c((crosspoint+1):sutun)]=dizip[baba,c((crosspoint+1):sutun)]
   }
      s=sebnemGeneticP4fit(dizi,data,nofstrata,ssize)
      dizix=cbind(dizi,s)
      sebnemGeneticP4x=rbind(parents, dizix)
      sebnemGeneticP4x=sebnemGeneticP4x[order(sebnemGeneticP4x[,(sutun+1)]),]
      sebnemGeneticP4x=sebnemGeneticP4x[c((satir+1):(satir*2)),c(1:sutun)]
	return(sebnemGeneticP4x)
 }
