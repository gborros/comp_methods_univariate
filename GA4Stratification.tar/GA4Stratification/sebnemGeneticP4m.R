   sebnemGeneticP4m=function(dizi,nofstrata,mut_rate,it)
   {

   	satir=nrow(dizi)
   	sutun=ncol(dizi)
   	for ( i in 1:satir )
   	{
   	   for ( k in 1:5 )
  	   {
    		if ( runif(1,0,1) < mut_rate )
 			{
				if ( runif(1,0,1) < mut_rate )
				{
					if ( it<50 )
			 		{
	               		nob=which(dizi[i,]==1,arr.ind=T)
      	         		zers=which(dizi[i,]==0,arr.ind=T)
            	   		mutnoktasi=nob[floor(runif(1,1,(length(nob)-1)))]
	               		mutnoktasi1=zers[floor(runif(1,1,length(zers)))]
	               		dizi[i,mutnoktasi]=0
	               		dizi[i,mutnoktasi1]=1
            	 	} else
			 		{ 
	               		nob=which(dizi[i,]==1,arr.ind=T)
            	   		mutnoktasi=nob[floor(runif(1,1,(length(nob)-1)))]
                   		if ( runif(1,0,1)<0.51 )
		             	{
							if ( dizi[i,(mutnoktasi+1)]==0 )
							{
								dizi[i,mutnoktasi]=0
		    		            dizi[i,(mutnoktasi+1)]=1
              		       	}
				 	     } else if ( mutnoktasi>1)
						 {
							if ( dizi[i,(mutnoktasi-1)]==0 ) 
							{
							       dizi[i,mutnoktasi]=0;
							       dizi[i,mutnoktasi-1]=1;     
							}
						 }
					}
    			}
			}
  		}
   	}
   return(dizi)
   }
   

