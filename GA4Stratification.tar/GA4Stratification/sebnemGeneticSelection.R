 sebnemGeneticSelection=function(dizi,uygunluk)
   {
   	satir=nrow(dizi)
	sutun=ncol(dizi)
   	selectionstrata=array(0,dim=c(satir,(sutun+1)))
   	yenidizi=cbind(dizi, -uygunluk)
   	sorteddizi=yenidizi[order(yenidizi[,sutun+1]),]
   	sorteduygunluk=uygunluk[order(-uygunluk),]
   	wheeleski = sorteduygunluk / sum(uygunluk)
	wheel=1:satir

	for(i in satir:1)
	{
		wheel[satir+1-i]=wheeleski[i]
	}
	wheel=cumsum(wheel)

   	for ( i in  1:satir )
   	{
		r = runif(1,0,1)
		for ( j in  1:satir )
		{
			if(r < wheel[j])
			{
				selectionstrata[i,] = sorteddizi[j,]
				break;
			}
		}
	}
	randpop=selectionstrata[,1:sutun]
	fitnesspop=selectionstrata[,(sutun+1)]
	return(randpop)
   }
